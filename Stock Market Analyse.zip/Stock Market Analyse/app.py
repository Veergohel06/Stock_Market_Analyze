from flask import Flask, request, render_template
import plotly.graph_objs as go
import pandas as pd
from sklearn.linear_model import LinearRegression
import numpy as np
import os

app = Flask(__name__)

# --- Paths ---
DATA_PATH = os.path.join(os.path.dirname(__file__), 'Datasets')

# --- Dataset cleaner ---
def clean_data(df):
    df.columns = df.columns.str.strip().str.lower()

    if 'close/last' in df.columns:
        df.rename(columns={'close/last': 'close'}, inplace=True)

    required = ['date', 'open', 'high', 'low', 'close', 'volume']
    if not all(col in df.columns for col in required):
        print("❌ Missing required columns:", df.columns)
        return None

    # Fix date parsing (assuming MM/DD/YYYY format)
    df['date'] = pd.to_datetime(df['date'], format='%m/%d/%Y', errors='coerce')

    # Clean dollar values
    df['close'] = pd.to_numeric(df['close'].replace(r'[\$,]', '', regex=True), errors='coerce')

    df = df.dropna(subset=['date', 'close'])
    df = df[df['close'] > 0]

    df.sort_values(by='date', inplace=True)
    df.reset_index(drop=True, inplace=True)
    return df



# --- Load data with error handling ---
def load_stock_data(filename):
    path = os.path.join(DATA_PATH, filename)
    try:
        df = pd.read_csv(path)
        return clean_data(df)
    except Exception as e:
        print(f"❌ Failed to load {filename}: {e}")
        return None

# --- Load all datasets ---
stock_datasets = {
    "amazon": load_stock_data("Amazon.csv"),
    "apple": load_stock_data("Apple.csv"),
    "google": load_stock_data("Google.csv"),
    "meta": load_stock_data("Meta.csv"),
    "microsoft": load_stock_data("Microsoft.csv"),
    "netflix": load_stock_data("Netflix.csv"),
    "nvidia": load_stock_data("Nvidia.csv"),
}

# --- Debug print ---
for name, df in stock_datasets.items():
    if df is None:
        print(f"❌ {name.capitalize()} data failed to load.")
    else:
        print(f"✅ {name.capitalize()} loaded with {len(df)} records.")

# --- Homepage ---
@app.route('/')
def index():
    return render_template('index.html')

# --- Prediction model ---
def get_prediction_model(df):
    df['day'] = np.arange(len(df))
    X = df[['day']]
    y = df['close']
    model = LinearRegression().fit(X, y)
    return model, X, y

# --- Generate plots ---
def generate_plots(df, company_name):
    plots = []

    fig1 = go.Figure([go.Scatter(x=df['date'], y=df['close'], mode='lines')])
    fig1.update_layout(title=f'{company_name} Closing Price')
    plots.append(fig1.to_html(full_html=False))

    fig2 = go.Figure([go.Bar(x=df['date'], y=df['volume'])])
    fig2.update_layout(title=f'{company_name} Volume')
    plots.append(fig2.to_html(full_html=False))

    fig3 = go.Figure([go.Candlestick(x=df['date'], open=df['open'], high=df['high'],
                                     low=df['low'], close=df['close'])])
    fig3.update_layout(title=f'{company_name} Candlestick')
    plots.append(fig3.to_html(full_html=False))

    df['daily return'] = df['close'].pct_change()
    fig4 = go.Figure([go.Scatter(x=df['date'], y=df['daily return'], mode='lines')])
    fig4.update_layout(title=f'{company_name} Daily Return')
    plots.append(fig4.to_html(full_html=False))

    model, X, y = get_prediction_model(df)
    fig5 = go.Figure()
    fig5.add_trace(go.Scatter(x=X['day'], y=y, mode='markers', name='Actual'))
    fig5.add_trace(go.Scatter(x=X['day'], y=model.predict(X), mode='lines', name='Predicted'))
    fig5.update_layout(title=f'{company_name} Price Prediction')
    plots.append(fig5.to_html(full_html=False))

    return plots

# --- Stock handler ---
@app.route('/submit_stock', methods=['POST'])
def submit_stock():
    stock_name = request.form['stockName'].strip().lower()

    if stock_name in stock_datasets and stock_datasets[stock_name] is not None:
        df = stock_datasets[stock_name]
        plots = generate_plots(df, stock_name.capitalize())
        return render_template('submit_stock.html', company=stock_name.capitalize(), plots=plots)
    else:
        return "<h2>❌ Stock not found or failed to load. Please enter a valid stock name like Amazon, Apple, Google, Meta, Microsoft, Netflix, or Nvidia.</h2>"

# --- Run ---
if __name__ == '__main__':
    app.run(debug=True)
